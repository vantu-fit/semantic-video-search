import json
import boto3
import os

# Khởi tạo client SageMaker Runtime
sagemaker_runtime = boto3.client("sagemaker-runtime")

endpoint_name = os.environ.get("SAGEMAKER_ENDPOINT_NAME")
if not endpoint_name:
    raise ValueError("SAGEMAKER_ENDPOINT_NAME environment variable is required")


def lambda_handler(event, context):
    try:
        # Lấy dữ liệu từ body của yêu cầu
        body = json.loads(event["body"])
        text = body.get("text", "")

        if not text:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Text field is required"}),
            }

        # Gọi SageMaker Endpoint
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=endpoint_name,  # Đặt tên endpoint SageMaker của bạn ở đây
            Body=json.dumps({"text": text}),
            ContentType="application/json",
        )

        # Xử lý phản hồi từ SageMaker
        response_body = json.loads(response["Body"].read().decode("utf-8"))

        return {"statusCode": 200, "body": json.dumps(response_body)}

    except Exception as e:
        print(f"Error: {e}")
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
